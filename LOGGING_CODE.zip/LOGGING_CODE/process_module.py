def process_waste(waste_type, quan):
    waste_data = {
        'type': waste_type,
        'quantity': quan  # Example: assuming the waste quantity is 10 for now
    }
    return waste_data
